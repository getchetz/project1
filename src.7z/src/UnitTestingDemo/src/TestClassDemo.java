import org.junit.Test;

import junit.framework.Assert;


public class TestClassDemo {

	@Test
	public void testSetterForFirstName(){
		System.out.println("Test method from TestClassDemo");
		Employee emp= new Employee();
		String name="Yogini";
		emp.setFirstName(name);
	   Assert.assertEquals(name, emp.getFirstName());
	}
	
}
