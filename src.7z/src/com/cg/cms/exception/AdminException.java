package com.cg.cms.exception;

public class AdminException extends Exception{
	public AdminException(String msg)
	{
		super(msg);
	}
	

}
