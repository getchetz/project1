package com.cg.cms.dto;

public class Mobiles {

}
