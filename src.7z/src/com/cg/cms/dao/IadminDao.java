package com.cg.cms.dao;

import com.cg.cms.dto.Purchasedetails;
import com.cg.cms.exception.AdminException;

public interface IadminDao {
	public Purchasedetails addCdetails(Purchasedetails purchase) throws AdminException;
	

}
