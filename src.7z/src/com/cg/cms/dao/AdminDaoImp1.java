package com.cg.cms.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.cg.cms.util.Databaseconnection;
import com.cg.cms.dto.Purchasedetails;
import com.cg.cms.exception.AdminException;

public class AdminDaoImp1 implements IadminDao{
	Connection connection;
	public AdminDaoImp1()
	{
		connection=Databaseconnection.getConnection();
	}

	@Override
	public Purchasedetails addCdetails(Purchasedetails purchase)
			throws AdminException {
		String sql="insert into purchasedetails(purchaseid,cname,mailid,phoneno,purchasedate,mobileid) values(?,?,?,?,?,?)";
		try
		{
			PreparedStatement ps=connection.prepareStatement(sql);
			ps.setInt(1,purchase.getPurchaseid());
			ps.setString(2,purchase.getCname());
			ps.setString(3,purchase.getMailid());
			ps.setString(4,purchase.getPhoneno());
			Date sqlDate=Date.valueOf(purchase.getPurchasedate());
			ps.setDate(5, sqlDate);
			ps.setInt(6,purchase.getMobileid());
			System.out.println("inserted....");
		
		}catch (SQLException e)
		{
			if(e.getErrorCode()==1){
				System.out.println("Purchase code already exists!!!!!!!");
			}
			else if(e.getErrorCode()==2291){
				System.out.println("Invalid MobileId!!!!");
			}
			else{
				System.out.println(e.getMessage());
			}
			
			
		}
		
		
		
		
		
		return purchase;
	}
}