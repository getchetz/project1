package com.cg.cms.service;

import com.cg.cms.dto.Purchasedetails;
import com.cg.cms.exception.AdminException;

public interface IadminService {
	public Purchasedetails addCdetails(Purchasedetails purchase) throws AdminException;

}
