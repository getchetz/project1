package com.cg.demo;

import java.util.Scanner;

public class Demo {

	public static void main(String[] args) {
		
		Employee emp= new Employee();
		Scanner sc= new Scanner(System.in);

		System.out.println("Enter Name : " );
		String name= sc.next();
		System.out.println("Enter Id : ");
		int id= sc.nextInt();
		System.out.println("Enter Salary :");
		double sal= sc.nextDouble();
		System.out.println("Enter Location ");
		String loc= sc.next();
		System.out.println("Enter Gender ");
		String gen= sc.next();
		
		
		emp.setEmpid(id);
		emp.setName(name);
		emp.setLocation(loc);
		emp.setSalary(sal);
		emp.setGender(gen);
		
		System.out.println(emp);
		
		
		
	}
}
