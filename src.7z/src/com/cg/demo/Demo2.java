package com.cg.demo;

import java.util.ArrayList;
import java.util.Collections;

public class Demo2 {

	public static void main(String[] args) {
		Employee e1= new Employee(1, "Ankita", 14000, "Female", "Pune");
		Employee e2= new Employee(4, "Neha", 8000, "Female", "Mumbai");
		Employee e3= new Employee(3, "Ditya", 25000, "Female", "Mumbai");
		Employee e4= new Employee(2, "Akash", 23000, "Male", "Chennai");
		Employee e5= new Employee(5, "Nikita", 63000, "Female", "Pune");
			
		ArrayList<Employee> list= new ArrayList<>();
		list.add(e1);
		list.add(e2);
		list.add(e3);
		list.add(e4);
		list.add(e5);
		//IdComparator com= new IdComparator();
	//	SalaryComp com= new SalaryComp();
		SalaryDescComparator com= new SalaryDescComparator();
		Collections.sort(list, com);
		
		for(Employee emp :  list){
			System.out.println(emp);
		}
		
		
	}
}
