package com.cg.demo;

public class Employee  implements Comparable<Employee>{

	private int empid;
	private String name;
	private double salary;
	private String gender;
	private String location ;

	
	@Override
	public String toString() {
	
			return empid+" "+ name+" "+ salary+" "+ gender+" "+ location;
	
	}
	
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	//default constr 
	public Employee(){
		location="Pune";
	}
	//param constr 
	public Employee(int empid, String name, double salary, String gender,
			String location) {
		//super();   //dafault constr from Object class
		this.empid = empid;
		this.name = name;
		this.salary = salary;
		this.gender = gender;
		this.location = location;
	}
	public int compareTo(Employee o) {
		
		if( this.getSalary() > o.getSalary())
			return 1;
		else if ( this.getSalary() < o.getSalary())
			return -1;
		return 0;
	}


}
