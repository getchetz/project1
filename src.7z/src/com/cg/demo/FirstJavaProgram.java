package com.cg.demo;

public class FirstJavaProgram {

public static void main(String[] args) {
	
	int i=1;
	do {
		System.out.println("Hello Java");
		i++;
	} while (i<=10);
	}
}
