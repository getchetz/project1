package com.cg.demo;

import java.io.ObjectInputStream.GetField;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

public class ArrayListDemo {

	public static void main(String[] args) {
		
		
		HashSet<Integer> list= new  HashSet<>();
		
		list.add(45);
		list.add(62);
		list.add(25);
		list.add(62);
		list.add(89);
		list.add(4);
		list.add(85);
		
		/*int size= list.size();
		for(int i=0;i<size;i++)
		System.out.println(list.get(i));*/
		
		for(int num : list){
			System.out.println(num);
		}
		
		System.out.println("using iterator : ");
		Iterator<Integer> itr= list.iterator();
		
		while(itr.hasNext()){
				int num= itr.next();
				System.out.println(num);
		}
		
		
		
		
		
		
		
		
		
	}
}
