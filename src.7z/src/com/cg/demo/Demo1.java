package com.cg.demo;

import java.util.TreeSet;

public class Demo1{

	public static void main(String[] args) {
		TreeSet<Employee> tree= new TreeSet<>();
	
		Employee e1= new Employee(1, "Ankita", 14000, "Female", "Pune");
		Employee e2= new Employee(4, "Neha", 8000, "Female", "Mumbai");
		Employee e3= new Employee(3, "Ditya", 25000, "Female", "Mumbai");
		Employee e4= new Employee(2, "Akash", 23000, "Male", "Chennai");
		Employee e5= new Employee(5, "Nikita", 63000, "Female", "Pune");
		
		tree.add(e1);
		tree.add(e2);
		tree.add(e3);
		tree.add(e4);
		tree.add(e5);
		System.out.println("size :"+ tree.size()  );
  	
	for(Employee emp : tree){
		System.out.println(emp);
	}
	
	
	}
}