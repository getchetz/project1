package com.cg.enumdemo;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import com.cg.enums.Month;
import com.cg.validation.DataValidator;


public class Demo1 {

	public static void main(String[] args) {
		Employee emp= new Employee();
		
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter First Name ");
		String fname= sc.next();
		System.out.println("Enter Last Name ");
		String lname= sc.next();
		LocalDate dt;
		while(true){
		try {
			System.out.println("Enter Joindate as (dd/MM/yyyy) : " );
			String date =sc.next();
			DateTimeFormatter formatter= 
					DateTimeFormatter.ofPattern("dd/MM/yyyy");
			dt = LocalDate.parse(date, formatter);
			emp.setJoindate(dt);
			break;
		} catch (Exception e) {
			System.out.println("Invalid date formate ...");
			}
		}
		System.out.println("Enter email " );
		String email= sc.next();
		System.out.println("Enter mobileno ");
		String mobno= sc.next();
		System.out.println("Enter empid " );
		String empid= sc.next();
		
		emp.setFirstName(fname);
		emp.setLastName(lname);
		emp.setEmail(email);
		emp.setEmpid(empid);
		emp.setMobileno(mobno);
		DataValidator validator= new DataValidator();
		boolean res= validator.validateInput(emp);
		if(res){
		System.out.println(emp.getFirstName());
		System.out.println(emp.getLastName());
		System.out.println(emp.getJoindate());
		System.out.println(emp.getEmail());
		System.out.println(emp.getMobileno());
		}
		else
			System.out.println("invalid input entered");
}
}
