package com.cg.validation;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.enumdemo.Employee;

public class DataValidator {

	public boolean validateInput(Employee emp){
		if(validateId(emp.getEmpid()) 
		   && validateMobileno(emp.getMobileno())
		   &&validateEmail(emp.getEmail()))
		return true;
		
		return false;
	}
	public boolean validateId(String empid){
		Pattern pattern= Pattern.compile("[0-9]{6}");
		Matcher mat= pattern.matcher(empid);
		if(mat.matches())
			return true;
		else
			return false;
		
	}
	public boolean validateEmail(String email){
		Pattern pattern= Pattern.compile("[a-zA-Z0-9]*@capgemini.com");
		Matcher mat= pattern.matcher(email);
		if(mat.matches())
			return true;
		else
			return false;
	}
	public boolean validateMobileno(String mobno){
		Pattern pattern= Pattern.compile("[0-9]{10}");
		Matcher mat= pattern.matcher(mobno);
		if(mat.matches())
			return true;
		else
			return false;
	}
}
