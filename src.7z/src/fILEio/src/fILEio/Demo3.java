package fILEio;

import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class Demo3 {

	public static void main(String[] args) {
		try {
			FileInputStream fis= new FileInputStream("basic.txt");
			DataInputStream dis= new DataInputStream(fis);
			int rollno= dis.readInt();
			String name= dis.readUTF();
			String add= dis.readUTF();
			double percent= dis.readDouble();
			System.out.println(rollno+ " " + name+" "+ add+" "+ percent);
			dis.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
