package fILEio;

import java.io.IOException;

public class Demo1 {

	public static void main(String[] args) {
		
		StringBuffer sb=new StringBuffer();
		System.out.println("Enter 1 line of text ");
		char ch;
		try {
			while( (ch= (char) System.in.read())!='\n'){
				sb.append(ch);
			}		
			System.out.println(sb);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
