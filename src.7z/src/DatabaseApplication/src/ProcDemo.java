import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;


public class ProcDemo {

	public static void main(String[] args) {
		
		String sql= "{ call getStudentDetails (?,?,?,?)} ";
		Connection con =DatabaseConnection.getConnection();
		try {
			CallableStatement cs=con.prepareCall(sql);
			cs.setInt(1, 13);
			cs.registerOutParameter(2, Types.VARCHAR);
			cs.registerOutParameter(3, Types.VARCHAR);
			cs.registerOutParameter(4, Types.INTEGER);
			cs.execute();
			
			String studName= cs.getString(2);
			String course= cs.getString(3);
			int duration= cs.getInt(4);
			System.out.println(studName+ " "+ course+"  "+ duration);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
