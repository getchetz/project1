import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;


public class DeleteDemo {

	public static void main(String[] args) {
		String sql="delete from student where student_code=?";
		int code ;
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter student code ");
		code= sc.nextInt();
		Connection con= DatabaseConnection.getConnection();
		try {
			PreparedStatement ps= con.prepareStatement(sql);
			ps.setInt(1, code);
			int row= ps.executeUpdate();
			System.out.println(row+" deleted ");
		} catch (SQLException e) {
			
			e.printStackTrace();
		}

	}
}
