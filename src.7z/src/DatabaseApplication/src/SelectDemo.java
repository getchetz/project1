import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Scanner;


public class SelectDemo {
public static void main(String[] args) {
	
	String sql="Select student_code, name,enrollDate "
			+ " from student "
			+ " where course_code=(select course_code "
			+ "  from course where coursename=?)";
	Scanner sc= new Scanner(System.in);
	System.out.println("Enter Course Name");
	String code= sc.next();
	LocalDate dt=null;
	Connection con= DatabaseConnection.getConnection();
	try {
		PreparedStatement ps= con.prepareStatement(sql);
		ps.setString(1, code);	
		ResultSet rs = ps.executeQuery();
		while(rs.next()){
			int scode= rs.getInt("student_code");
			String  name= rs.getString("name");
			Date date= rs.getDate("enrollDate");
			if(date!=null)
			{
			dt= date.toLocalDate();
			}
			System.out.println(scode+ " "+ name+ " "+ dt);	
		}
		rs.close();
		ps.close();
		con.close();
	} catch (SQLException e) {
		e.printStackTrace();
	}
	
	
			
}
}
